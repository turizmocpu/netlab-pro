@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
echo NetLab Pro - сборка Windows x64
where node >nul 2>&1
if errorlevel 1 goto nonode
node -e "process.exit(+process.versions.node.split('.')[0]>=18?0:1)"
if errorlevel 1 goto oldnode
node scripts\build.js
if errorlevel 1 goto fail
echo.
echo Успешно. Установщик и portable-версия лежат в папке dist.
goto end
:nonode
echo ОШИБКА: Node.js не найден. Установите LTS-версию с https://nodejs.org и запустите файл снова.
goto end
:oldnode
echo ОШИБКА: нужен Node.js версии 18 или новее. Обновите Node.js с https://nodejs.org
goto end
:fail
echo.
echo СБОРКА НЕ ЗАВЕРШЕНА. Причина выше; полный лог: build-log.txt
:end
echo.
pause
