'use strict';
// Сборка с повторами при сетевых ошибках, логом и проверкой результата.
const { spawn } = require('child_process');
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const logPath = path.join(root, 'build-log.txt');
const log = fs.createWriteStream(logPath, { flags: 'w' });
const out = (s) => { process.stdout.write(s); log.write(s); };
const say = (s) => out(s + '\n');
const isWin = process.platform === 'win32';
const delay = +process.env.NETLAB_RETRY_DELAY_MS || 15000;
const MAX = 5;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const transient = /ECONNRESET|ETIMEDOUT|ECONNREFUSED|EAI_AGAIN|ENOTFOUND|ESOCKETTIMEDOUT|EPROTO|socket hang up|getaddrinfo|dial tcp|net\/http|reset by peer|network|\b50[234]\b|Client network socket disconnected/i;

function run(cmd, args) {
  return new Promise((resolve) => {
    let tail = '';
    const c = spawn(isWin ? cmd + '.cmd' : cmd, args, { cwd: root, shell: isWin, env: { ...process.env, CSC_IDENTITY_AUTO_DISCOVERY: 'false' } });
    const f = (d) => { const s = d.toString(); tail = (tail + s).slice(-6000); out(s); };
    c.stdout.on('data', f); c.stderr.on('data', f);
    c.on('error', (e) => { say('Не удалось запустить ' + cmd + ': ' + e.message); resolve({ code: 1, tail: String(e) }); });
    c.on('close', (code) => resolve({ code, tail }));
  });
}

async function step(title, cmd, args, retry) {
  for (let a = 1; a <= MAX; a++) {
    say(`\n=== ${title} (попытка ${a} из ${retry ? MAX : 1}) ===`);
    const r = await run(cmd, args);
    if (r.code === 0) return true;
    if (/Cannot create symbolic link|symlink/i.test(r.tail)) say('Подсказка: включите «Режим разработчика» Windows или запустите сборку от имени администратора, затем повторите.');
    if (retry && a < MAX && transient.test(r.tail)) {
      say(`Похоже на временную сетевую ошибку. Повтор через ${Math.round(delay * a / 1000)} с (кэш npm сохраняется, загрузка продолжится)...`);
      await sleep(delay * a); continue;
    }
    say(`\nШАГ НЕ УДАЛСЯ: ${title} (код ${r.code}).`);
    if (transient.test(r.tail)) say('Причина — сеть: проверьте интернет, VPN/прокси/антивирус и запустите build.bat ещё раз; уже скачанное будет взято из кэша.');
    return false;
  }
  return false;
}

function finish(ok) { log.end(() => process.exit(ok ? 0 : 1)); }

(async () => {
  say(`NetLab Pro: сборка. Node ${process.version}, ${process.platform}. ${new Date().toISOString()}`);
  say('Во время сборки нужен интернет (npm, Electron, инструменты electron-builder). Готовому установщику интернет не нужен.');
  if (!(await step('Установка зависимостей', 'npm', ['install', '--no-audit', '--no-fund'], true))) { say('Лог: ' + logPath); return finish(false); }
  if (!(await step('Проверка: тесты симулятора', 'npm', ['test'], false))) { say('Лог: ' + logPath); return finish(false); }
  if (!(await step('Сборка установщика и portable', 'npm', ['run', 'dist'], true))) { say('Лог: ' + logPath); return finish(false); }
  const files = ['NetLabPro-Setup.exe', 'NetLabPro-Portable.exe'].map((f) => path.join(root, 'dist', f));
  const missing = files.filter((f) => !fs.existsSync(f));
  if (missing.length) { say('Сборка завершилась, но файлов нет: ' + missing.join(', ')); say('Лог: ' + logPath); return finish(false); }
  say('\nГОТОВО. Файлы в папке dist:');
  files.forEach((f) => say(`  ${path.basename(f)}  ${(fs.statSync(f).size / 1048576).toFixed(1)} МБ`));
  say('Лог: ' + logPath);
  finish(true);
})();
