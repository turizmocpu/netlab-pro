// Runs the simulation self-tests from src/index.html in Node with the DOM stubbed out.
const vm = require('vm'), fs = require('fs'), path = require('path');
const html = fs.readFileSync(path.join(__dirname, '..', 'src', 'index.html'), 'utf8');
const js = html.split('<script>')[1].split('</script>')[0];
const el = () => new Proxy(function () {}, { get: (t, k) => k == 'classList' ? { toggle() {}, add() {}, remove() {} } : k == 'style' ? {} : k == 'createSVGPoint' ? () => ({ matrixTransform: () => ({ x: 0, y: 0 }) }) : k == 'getScreenCTM' ? () => ({ inverse: () => ({}) }) : el(), set: () => true, apply: () => el() });
const ctx = { window: {}, document: { querySelector: () => el(), createElement: () => ({}) }, addEventListener() {}, localStorage: { getItem: () => null, setItem() {} }, performance, requestAnimationFrame() {}, setTimeout, clearTimeout, confirm: () => true, console };
vm.createContext(ctx);
vm.runInContext(js + ';\nglobalThis.__r = tests();', ctx);
let bad = 0; for (const [n, ok] of ctx.__r) { console.log((ok ? 'PASS ' : 'FAIL ') + n); if (!ok) bad++; }
console.log(ctx.__r.length - bad + '/' + ctx.__r.length + ' passed'); process.exit(bad ? 1 : 0);
